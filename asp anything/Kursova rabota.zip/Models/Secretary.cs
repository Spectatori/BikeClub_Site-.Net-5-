﻿namespace asp_anything.Models
{
    public class Secretary : Member
    {

    }
}
