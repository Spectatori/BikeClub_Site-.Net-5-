﻿namespace asp_anything.Models
{
    public class Member : User
    {

    }
}
