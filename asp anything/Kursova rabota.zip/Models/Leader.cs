﻿namespace asp_anything.Models
{
    public class Leader : Secretary
    {
        
    }
}
